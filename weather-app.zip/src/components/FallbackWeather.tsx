"use client"

import { useState, useEffect } from "react"
import type { WeatherData } from "../services/weather-service"
import { getWeatherIcon } from "./CurrentWeather"

export function generateFallbackWeather(location: string): WeatherData {
  const conditions = ["Clear", "Clouds", "Rain", "Snow"]
  const randomCondition = conditions[Math.floor(Math.random() * conditions.length)]

  return {
    location,
    current: {
      temp: Math.floor(Math.random() * 30) + 5,
      feels_like: Math.floor(Math.random() * 30) + 5,
      humidity: Math.floor(Math.random() * 100),
      wind: Math.floor(Math.random() * 30),
      condition: randomCondition,
      icon: "01d",
    },
    forecast: Array.from({ length: 5 }, (_, i) => {
      const condition = conditions[Math.floor(Math.random() * conditions.length)]
      const temp = Math.floor(Math.random() * 30) + 5
      return {
        day: new Date(Date.now() + i * 86400000).toLocaleDateString("en-US", { weekday: "short" }),
        temp,
        min: temp - Math.floor(Math.random() * 5),
        max: temp + Math.floor(Math.random() * 5),
        condition,
        icon: "01d",
      }
    }),
  }
}

interface FallbackWeatherProps {
  location: string
  error: string
}

export function FallbackWeather({ location, error }: FallbackWeatherProps) {
  const [fallbackData, setFallbackData] = useState<WeatherData | null>(null)

  useEffect(() => {
    setFallbackData(generateFallbackWeather(location))
  }, [location])

  if (!fallbackData) return null

  return (
    <div className="mt-4">
      <div className="p-4 bg-gray-100 rounded-lg mt-4">
        <h3 className="font-medium mb-2">Demo Mode (Using Simulated Data)</h3>
        <p className="text-sm text-gray-600 mb-4">
          Showing simulated weather data while API connection is being fixed.
        </p>

        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">{fallbackData.location}</h2>
            <p className="text-sm text-gray-500">Simulated Data</p>
          </div>
          <div className="flex items-center gap-2">
            {getWeatherIcon(fallbackData.current.condition)}
            <span className="text-2xl font-bold">{fallbackData.current.temp}°C</span>
          </div>
        </div>
      </div>
    </div>
  )
}

