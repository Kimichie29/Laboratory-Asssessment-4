"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { fetchWeatherData, type WeatherData } from "../services/weather-service"
import { SearchBar } from "./SearchBar"
import { CurrentWeather, getBackgroundClass } from "./CurrentWeather"
import { Forecast } from "./Forecast"
import { WeatherDetails } from "./WeatherDetails"
import { ErrorMessage } from "./ErrorMessage"
import { API_KEY } from "../services/weather-service"
import { FallbackWeather } from "./FallbackWeather"

export default function WeatherApp() {
  const [location, setLocation] = useState("London")
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [apiKeyValid, setApiKeyValid] = useState(true)

  useEffect(() => {
    async function getWeather() {
      setLoading(true)
      setError(null)

      // Check if API key is still the placeholder
      if (API_KEY === "YOUR_API_KEY") {
        setApiKeyValid(false)
        setLoading(false)
        setError("Please add your OpenWeatherMap API key in services/weather-service.ts")
        return
      }

      try {
        const data = await fetchWeatherData(location)
        setWeather(data)
        setApiKeyValid(true)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to fetch weather data")
        console.error("Error fetching weather:", err)
      } finally {
        setLoading(false)
      }
    }

    getWeather()
  }, [location])

  const handleSearch = (searchLocation: string) => {
    setLocation(searchLocation)
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-6">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader
          className={`rounded-t-lg ${weather ? getBackgroundClass(weather.current.condition) : "bg-gradient-to-br from-blue-50 to-gray-100"}`}
        >
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl font-bold">Weather App</CardTitle>
            <SearchBar onSearch={handleSearch} />
          </div>
          {weather && <CurrentWeather weather={weather} />}
        </CardHeader>
        <CardContent className="pt-6">
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : error ? (
            <>
              <ErrorMessage message={error} />
              {!apiKeyValid && <FallbackWeather location={location} error={error} />}
            </>
          ) : weather ? (
            <Tabs defaultValue="forecast" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="forecast">Forecast</TabsTrigger>
                <TabsTrigger value="details">Details</TabsTrigger>
              </TabsList>
              <TabsContent value="forecast" className="mt-4">
                <Forecast forecast={weather.forecast} />
              </TabsContent>
              <TabsContent value="details" className="mt-4">
                <WeatherDetails current={weather.current} />
              </TabsContent>
            </Tabs>
          ) : (
            <CardDescription className="text-center py-10">
              No weather data available. Please search for a location.
            </CardDescription>
          )}
        </CardContent>
        <CardFooter className="text-xs text-gray-500 justify-center">
          Weather data provided by OpenWeatherMap
        </CardFooter>
      </Card>
    </div>
  )
}

