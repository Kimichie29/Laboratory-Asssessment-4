import type { WeatherData } from "../services/weather-service"
import { getWeatherIcon } from "./CurrentWeather"

interface ForecastProps {
  forecast: WeatherData["forecast"]
}

export function Forecast({ forecast }: ForecastProps) {
  return (
    <div className="grid grid-cols-5 gap-2">
      {forecast.map((day, index) => (
        <ForecastItem key={index} day={day} />
      ))}
    </div>
  )
}

interface ForecastItemProps {
  day: WeatherData["forecast"][0]
}

function ForecastItem({ day }: ForecastItemProps) {
  return (
    <div className="flex flex-col items-center p-2 rounded-lg hover:bg-gray-100">
      <span className="text-sm font-medium">{day.day}</span>
      {getWeatherIcon(day.condition)}
      <div className="flex gap-1 mt-1">
        <span className="text-xs text-gray-500">{day.min}°</span>
        <span className="text-sm font-bold">{day.max}°</span>
      </div>
    </div>
  )
}

