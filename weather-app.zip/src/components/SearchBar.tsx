"use client"

import type React from "react"
import { useState } from "react"
import { Search } from "lucide-react"
import { Input } from "./ui/input"
import { Button } from "./ui/button"

interface SearchBarProps {
  onSearch: (location: string) => void
}

export function SearchBar({ onSearch }: SearchBarProps) {
  const [searchInput, setSearchInput] = useState("")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchInput.trim()) {
      onSearch(searchInput)
      setSearchInput("")
    }
  }

  return (
    <form onSubmit={handleSearch} className="flex gap-2">
      <Input
        type="text"
        placeholder="Search location..."
        value={searchInput}
        onChange={(e) => setSearchInput(e.target.value)}
        className="h-9 w-40 sm:w-auto bg-white/80 backdrop-blur-sm"
      />
      <Button type="submit" size="sm" variant="secondary" className="h-9">
        <Search className="h-4 w-4" />
      </Button>
    </form>
  )
}

