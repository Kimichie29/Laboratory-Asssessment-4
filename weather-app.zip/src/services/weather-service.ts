const API_KEY = "f089ddbaa13b0cac5e7524597ba463f7"
const BASE_URL = "https://api.openweathermap.org/data/2.5"

export interface WeatherData {
  location: string
  current: {
    temp: number
    feels_like: number
    humidity: number
    wind: number
    condition: string
    icon: string
  }
  forecast: Array<{
    day: string
    temp: number
    min: number
    max: number
    condition: string
    icon: string
  }>
}

export async function fetchWeatherData(location: string): Promise<WeatherData> {
  try {
    // First, get current weather (which includes coordinates)
    const currentResponse = await fetch(
      `${BASE_URL}/weather?q=${encodeURIComponent(location)}&units=metric&appid=${API_KEY}`,
    )

    if (!currentResponse.ok) {
      if (currentResponse.status === 401) {
        throw new Error("Invalid API key. Please check your OpenWeatherMap API key.")
      } else if (currentResponse.status === 404) {
        throw new Error(`Location "${location}" not found. Please try another location.`)
      } else {
        throw new Error(`API Error: ${currentResponse.status} ${currentResponse.statusText}`)
      }
    }

    const currentData = await currentResponse.json()
    const { lat, lon } = currentData.coord
    const locationName = currentData.name

    // Then, get 5-day forecast
    const forecastResponse = await fetch(`${BASE_URL}/forecast?lat=${lat}&lon=${lon}&units=metric&appid=${API_KEY}`)

    if (!forecastResponse.ok) {
      throw new Error("Failed to fetch forecast data")
    }

    const forecastData = await forecastResponse.json()

    // Process forecast data - get one forecast per day (noon)
    const dailyForecasts = []
    const processedDates = new Set()

    for (const item of forecastData.list) {
      const date = new Date(item.dt * 1000)
      const dateStr = date.toISOString().split("T")[0]

      // Skip today and only take one reading per day (around noon)
      const today = new Date().toISOString().split("T")[0]
      const hour = date.getHours()

      if (dateStr !== today && !processedDates.has(dateStr) && hour >= 11 && hour <= 13) {
        processedDates.add(dateStr)
        dailyForecasts.push({
          day: date.toLocaleDateString("en-US", { weekday: "short" }),
          temp: Math.round(item.main.temp),
          min: Math.round(item.main.temp_min),
          max: Math.round(item.main.temp_max),
          condition: item.weather[0].main,
          icon: item.weather[0].icon,
        })

        if (dailyForecasts.length >= 5) break
      }
    }

    // Format the data
    return {
      location: locationName,
      current: {
        temp: Math.round(currentData.main.temp),
        feels_like: Math.round(currentData.main.feels_like),
        humidity: currentData.main.humidity,
        wind: Math.round(currentData.wind.speed),
        condition: currentData.weather[0].main,
        icon: currentData.weather[0].icon,
      },
      forecast: dailyForecasts,
    }
  } catch (error) {
    console.error("Error fetching weather data:", error)
    throw error
  }
}

export { API_KEY }

