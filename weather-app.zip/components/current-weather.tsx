import { Cloud, CloudRain, Sun, Snowflake, Wind } from "lucide-react"
import type { WeatherData } from "@/services/weather-service"

interface CurrentWeatherProps {
  weather: WeatherData
}

export function CurrentWeather({ weather }: CurrentWeatherProps) {
  return (
    <div className="mt-6 flex justify-between items-center">
      <div>
        <h2 className="text-3xl font-bold">{weather.location}</h2>
        <p className="text-sm opacity-80">Today</p>
      </div>
      <div className="text-right">
        <div className="flex items-center gap-2">
          {getWeatherIcon(weather.current.condition)}
          <span className="text-3xl font-bold">{weather.current.temp}°C</span>
        </div>
        <p className="text-sm">{weather.current.condition}</p>
      </div>
    </div>
  )
}

export function getWeatherIcon(condition: string) {
  switch (condition.toLowerCase()) {
    case "clear":
      return <Sun className="h-8 w-8 text-yellow-500" />
    case "clouds":
      return <Cloud className="h-8 w-8 text-gray-500" />
    case "rain":
    case "drizzle":
      return <CloudRain className="h-8 w-8 text-blue-500" />
    case "thunderstorm":
      return <CloudRain className="h-8 w-8 text-purple-500" />
    case "snow":
      return <Snowflake className="h-8 w-8 text-blue-300" />
    default:
      return <Wind className="h-8 w-8 text-gray-400" />
  }
}

export function getBackgroundClass(condition: string) {
  switch (condition.toLowerCase()) {
    case "clear":
      return "bg-gradient-to-br from-yellow-100 to-blue-100"
    case "clouds":
      return "bg-gradient-to-br from-gray-100 to-gray-200"
    case "rain":
    case "drizzle":
      return "bg-gradient-to-br from-blue-100 to-gray-200"
    case "thunderstorm":
      return "bg-gradient-to-br from-indigo-100 to-gray-200"
    case "snow":
      return "bg-gradient-to-br from-blue-50 to-gray-100"
    default:
      return "bg-gradient-to-br from-blue-50 to-gray-100"
  }
}

