import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface ErrorMessageProps {
  message: string
}

export function ErrorMessage({ message }: ErrorMessageProps) {
  const isApiKeyError = message.includes("API key")

  return (
    <Alert variant="destructive" className="mb-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Error</AlertTitle>
      <AlertDescription className="mt-2">
        {message}

        {isApiKeyError && (
          <div className="mt-4">
            <p className="text-sm mb-2">To fix this:</p>
            <ol className="list-decimal list-inside text-sm space-y-1">
              <li>
                Sign up for a free API key at{" "}
                <a
                  href="https://openweathermap.org/api"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline"
                >
                  OpenWeatherMap
                </a>
              </li>
              <li>Replace 'YOUR_API_KEY' in services/weather-service.ts with your actual API key</li>
              <li>Refresh the page</li>
            </ol>
          </div>
        )}
      </AlertDescription>
    </Alert>
  )
}

