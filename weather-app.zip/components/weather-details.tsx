import type { WeatherData } from "@/services/weather-service"

interface WeatherDetailsProps {
  current: WeatherData["current"]
}

export function WeatherDetails({ current }: WeatherDetailsProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="bg-gray-100 p-3 rounded-lg">
        <p className="text-sm text-gray-500">Humidity</p>
        <p className="text-xl font-bold">{current.humidity}%</p>
      </div>
      <div className="bg-gray-100 p-3 rounded-lg">
        <p className="text-sm text-gray-500">Wind</p>
        <p className="text-xl font-bold">{current.wind} km/h</p>
      </div>
      <div className="bg-gray-100 p-3 rounded-lg">
        <p className="text-sm text-gray-500">Feels Like</p>
        <p className="text-xl font-bold">{current.feels_like}°C</p>
      </div>
      <div className="bg-gray-100 p-3 rounded-lg">
        <p className="text-sm text-gray-500">Condition</p>
        <p className="text-xl font-bold">{current.condition}</p>
      </div>
    </div>
  )
}

